function actualizaFormVersion(formulario)
{
    location.href=window.location+"&idmarca="+document.getElementById("jform_idMarca").value;
          
}

