<?php
// No permitir el acceso directo al archivo
defined('_JEXEC') or die('Restricted Access');
?>

<tr>
        <th width="1%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_SELECCIONAR'); ?>
        </th>
        <th width="1%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_ID'); ?>
        </th>
        <th width="4%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_MARCA'); ?>
        </th>
        <th width="4%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_MODELO'); ?>
        </th>
        <th width="5%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_NOMBREVERSION'); ?>
        </th>
        <th width="2%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_TIPO'); ?>
        </th>
        <th width="2%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_COMBUSTIBLE'); ?>
        </th>
        <th width="2%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_FECHAINICIAL'); ?>
        </th>
        <th width="2%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_FECHAFINAL'); ?>
        </th>
        <th width="2%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_KW'); ?>
        </th>
        <th width="2%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_CV'); ?>
        </th>
        <th width="2%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_CM3'); ?>
        </th>
        <th width="2%">
                <?php echo JText::_('COM_VEHICULO_VERSIONS_HEADING_NCILINDROS'); ?>
        </th>
        
</tr>
