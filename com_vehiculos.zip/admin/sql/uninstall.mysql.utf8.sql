DROP TABLE IF EXISTS `#__vehiculo_marcas`;
DROP TABLE IF EXISTS `#__vehiculo_modelos`;
DROP TABLE IF EXISTS `#__vehiculo_versiones`;
DROP TABLE IF EXISTS `#__vehiculo_tipos`;
DROP TABLE IF EXISTS `#__vehiculo_combustibles`;
